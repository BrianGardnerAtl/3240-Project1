//package descentParser;

class ParseException extends Exception {
    ParseException(String description) {
        super(description);
    }
}